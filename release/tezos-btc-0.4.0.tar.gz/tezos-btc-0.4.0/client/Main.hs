{- SPDX-FileCopyrightText: 2019 Bitcoin Suisse
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
module Main
  ( main
  ) where

import Client.Main

main :: IO ()
main = do
  env <- mkInitEnv
  runAppM env mainProgram
